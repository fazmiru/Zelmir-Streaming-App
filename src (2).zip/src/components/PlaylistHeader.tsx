import type { Track } from '../types'

interface PlaylistHeaderProps {
  name: string
  tracks: Track[]
}

export function PlaylistHeader({ name, tracks }: PlaylistHeaderProps) {
  // Up to 4 distinct thumbnails for the mosaic; if there are fewer than 4
  // tracks, just repeat what we have so the grid still fills in sensibly.
  const covers: string[] = []
  for (let i = 0; i < 4; i++) {
    if (tracks.length === 0) break
    covers.push(tracks[i % tracks.length].thumbnail)
  }

  return (
    <div className="playlist-header">
      {covers.length > 0 && (
        <div className="playlist-header-backdrop" aria-hidden="true">
          {covers.map((src, i) => (
            <img key={i} src={src} alt="" />
          ))}
          <div className="playlist-header-fade" />
        </div>
      )}

      <div className="playlist-header-content">
        <div className="playlist-cover-mosaic">
          {covers.length > 0 ? (
            covers.map((src, i) => <img key={i} src={src} alt="" />)
          ) : (
            <div className="playlist-cover-mosaic-empty" />
          )}
        </div>

        <div className="playlist-header-meta">
          <span className="playlist-header-label">Playlist</span>
          <h1 className="playlist-header-name">{name}</h1>
          <p className="playlist-header-count">
            {tracks.length} song{tracks.length === 1 ? '' : 's'}
          </p>
        </div>
      </div>
    </div>
  )
}
