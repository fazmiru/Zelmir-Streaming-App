import { useEffect, useRef, useState } from 'react'
import type { CSSProperties, TouchEvent as ReactTouchEvent } from 'react'
import type { Track, RepeatMode } from '../types'
import {
  PlayIcon,
  PauseIcon,
  NextIcon,
  PrevIcon,
  ShuffleIcon,
  RepeatIcon,
  CloseIcon,
} from './Icons'
import { searchPipedTracksSimple } from '../utils/piped'
import { fetchLyrics, approximateTimedLines, type LyricLine } from '../utils/lyrics'
import { extractAlbumColors } from '../utils/albumColors'

const COVER_FALLBACKS = ['maxresdefault', 'sddefault', 'hqdefault', 'mqdefault'] as const

type Tab = 'upnext' | 'lyrics' | 'recommended'

interface NowPlayingProps {
  track: Track
  queue: Track[]
  queueIndex: number
  isPlaying: boolean
  currentTime?: number
  duration?: number
  shuffle: boolean
  repeatMode: RepeatMode
  onClose: () => void
  onToggle: () => void
  onNext: () => void
  onPrev: () => void
  onSeek: (seconds: number) => void
  onToggleShuffle: () => void
  onCycleRepeat: () => void
  onPlayFromQueue: (track: Track, source: Track[]) => void
  onOpenArtist: (artist: string) => void
}

function formatTime(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00'
  const m = Math.floor(seconds / 60)
  const s = Math.floor(seconds % 60)
  return `${m}:${s.toString().padStart(2, '0')}`
}

export function NowPlaying({
  track,
  queue,
  queueIndex,
  isPlaying,
  currentTime = 0,
  duration = 0,
  shuffle,
  repeatMode,
  onClose,
  onToggle,
  onNext,
  onPrev,
  onSeek,
  onToggleShuffle,
  onCycleRepeat,
  onPlayFromQueue,
  onOpenArtist,
}: NowPlayingProps) {
  const [tab, setTab] = useState<Tab>('upnext')
  const [recommended, setRecommended] = useState<Track[]>([])
  const [loadingRecommended, setLoadingRecommended] = useState(false)
  const fetchedFor = useRef<string | null>(null)

  const [coverStage, setCoverStage] = useState(0)
  const coverSrc =
    coverStage < COVER_FALLBACKS.length
      ? `https://i.ytimg.com/vi/${track.videoId}/${COVER_FALLBACKS[coverStage]}.jpg`
      : track.thumbnail || `https://i.ytimg.com/vi/${track.videoId}/hqdefault.jpg`

  const [lyrics, setLyrics] = useState<string | null>(null)
  const [lyricLines, setLyricLines] = useState<LyricLine[] | null>(null)
  const [lyricsNotFound, setLyricsNotFound] = useState(false)
  const [loadingLyrics, setLoadingLyrics] = useState(false)
  const lyricsFetchedFor = useRef<string | null>(null)
  const activeLyricRef = useRef<HTMLParagraphElement | null>(null)

  const [albumColors, setAlbumColors] = useState<string[]>(['#c45c26', '#e8a04a', '#8b3a1a', '#f0c070'])

  // Mobile sheet (swipe up for queue) — YouTube Music style
  const [sheetOpen, setSheetOpen] = useState(false)
  const touchStartY = useRef<number | null>(null)

  const safeQueue = Array.isArray(queue) ? queue : []
  const upNext = safeQueue.slice(Math.max(0, queueIndex) + 1)
  const seekProgress = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0

  // Prefer real LRC; otherwise approximate from plain lyrics + duration
  const displayLines: LyricLine[] | null =
    lyricLines && lyricLines.length
      ? lyricLines
      : lyrics
        ? approximateTimedLines(lyrics, duration || 0)
        : null

  let activeLyricIndex = -1
  if (displayLines && displayLines.length) {
    for (let i = 0; i < displayLines.length; i++) {
      if (displayLines[i].time <= currentTime + 0.2) activeLyricIndex = i
      else break
    }
  }


  useEffect(() => {
    setCoverStage(0)
  }, [track.videoId])

  useEffect(() => {
    let cancelled = false
    extractAlbumColors(coverSrc).then((colors) => {
      if (!cancelled) setAlbumColors(colors)
    })
    return () => {
      cancelled = true
    }
  }, [coverSrc])

  useEffect(() => {
    if (tab !== 'lyrics') return
    if (lyricsFetchedFor.current === track.videoId) return
    lyricsFetchedFor.current = track.videoId
    setLoadingLyrics(true)
    setLyrics(null)
    setLyricLines(null)
    setLyricsNotFound(false)
    fetchLyrics(track.artist || '', track.title || '')
      .then((result) => {
        if (result?.lines && result.lines.length) {
          setLyricLines(result.lines)
          setLyrics(result.lyrics)
        } else if (result?.lyrics) {
          setLyrics(result.lyrics)
          setLyricLines(null)
        } else {
          setLyricsNotFound(true)
        }
      })
      .catch(() => setLyricsNotFound(true))
      .finally(() => setLoadingLyrics(false))
  }, [tab, track.videoId, track.artist, track.title])

  useEffect(() => {
    if (tab !== 'recommended') return
    if (fetchedFor.current === track.videoId) return
    fetchedFor.current = track.videoId
    setLoadingRecommended(true)
    setRecommended([])
    const q = `${track.artist || ''} ${(track.title || '').split(/[-(|]/)[0].trim()}`.trim()
    searchPipedTracksSimple(q)
      .then((tracks) => {
        setRecommended((tracks || []).filter((t) => t.videoId !== track.videoId).slice(0, 20))
      })
      .catch(() => setRecommended([]))
      .finally(() => setLoadingRecommended(false))
  }, [tab, track.videoId, track.artist, track.title])

  const npStyle = {
    '--np-c0': albumColors[0],
    '--np-c1': albumColors[1],
    '--np-c2': albumColors[2],
    '--np-c3': albumColors[3],
  } as CSSProperties

  useEffect(() => {
    if (tab !== 'lyrics') return
    if (activeLyricIndex < 0) return
    activeLyricRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' })
  }, [activeLyricIndex, tab])

  const onTouchStart = (e: ReactTouchEvent) => {
    touchStartY.current = e.touches[0].clientY
  }
  const onTouchEnd = (e: ReactTouchEvent) => {
    if (touchStartY.current == null) return
    const dy = e.changedTouches[0].clientY - touchStartY.current
    touchStartY.current = null
    // swipe up → open sheet, swipe down → close sheet or now playing
    if (dy < -48) setSheetOpen(true)
    else if (dy > 64) {
      if (sheetOpen) setSheetOpen(false)
      else onClose()
    }
  }

  const panelBody = (
    <>
      {tab === 'upnext' && (
        <>
          {upNext.length === 0 && (
            <p className="now-playing-empty">No more songs in the queue.</p>
          )}
          {upNext.map((t, i) => (
            <div
              key={`${t.videoId}-${i}`}
              className="now-playing-row"
              role="button"
              tabIndex={0}
              onClick={() => onPlayFromQueue(t, safeQueue)}
            >
              <img src={t.thumbnail} alt="" className="now-playing-row-thumb" />
              <div className="now-playing-row-meta">
                <span className="now-playing-row-title">{t.title}</span>
                <span className="now-playing-row-artist">{t.artist}</span>
              </div>
            </div>
          ))}
          {/* current at top when sheet */}
          <div className="now-playing-row now-playing-row-current" style={{ order: -1 }}>
            <img src={track.thumbnail || coverSrc} alt="" className="now-playing-row-thumb" />
            <div className="now-playing-row-meta">
              <span className="now-playing-row-title">{track.title}</span>
              <span className="now-playing-row-artist">{track.artist}</span>
            </div>
          </div>
        </>
      )}
      {tab === 'lyrics' && (
        <div className="now-playing-lyrics">
          {loadingLyrics && <p className="now-playing-empty">Loading lyrics…</p>}
          {!loadingLyrics && lyricsNotFound && (
            <p className="now-playing-empty">No lyrics found for this track.</p>
          )}
          {!loadingLyrics && displayLines && displayLines.length > 0 && (
            <div className="now-playing-lyrics-sync">
              {displayLines.map((line, i) => {
                const state =
                  i < activeLyricIndex ? 'past' : i === activeLyricIndex ? 'active' : 'future'
                return (
                  <p
                    key={`${line.time}-${i}`}
                    ref={i === activeLyricIndex ? activeLyricRef : undefined}
                    className={`np-lyric-line np-lyric-${state}`}
                  >
                    {line.text}
                  </p>
                )
              })}
            </div>
          )}
        </div>
      )}
      {tab === 'recommended' && (
        <>
          {loadingRecommended && <p className="now-playing-empty">Finding similar songs…</p>}
          {!loadingRecommended &&
            recommended.map((t, i) => (
              <div
                key={`${t.videoId}-r-${i}`}
                className="now-playing-row"
                role="button"
                tabIndex={0}
                onClick={() => onPlayFromQueue(t, [t, ...recommended])}
              >
                <img src={t.thumbnail} alt="" className="now-playing-row-thumb" />
                <div className="now-playing-row-meta">
                  <span className="now-playing-row-title">{t.title}</span>
                  <span className="now-playing-row-artist">{t.artist}</span>
                </div>
              </div>
            ))}
          {!loadingRecommended && recommended.length === 0 && (
            <p className="now-playing-empty">No recommendations found.</p>
          )}
        </>
      )}
    </>
  )

  return (
    <div
      className={`now-playing-overlay ${sheetOpen ? 'np-sheet-open' : ''}`}
      style={npStyle}
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
    >
      <div className="now-playing-backdrop" aria-hidden="true">
        <img className="now-playing-backdrop-img" src={coverSrc} alt="" />
        <div className="now-playing-backdrop-shade" />
      </div>

      {/* ===== Desktop / tablet layout (unchanged structure) ===== */}
      <div className="now-playing-body now-playing-body-desktop">
        <div className="now-playing-left">
          <div className="now-playing-cover-wrap">
            <button type="button" className="now-playing-close" onClick={onClose} aria-label="Close">
              <CloseIcon size={18} />
            </button>
            <img
              className="now-playing-cover"
              src={coverSrc}
              alt=""
              onError={() => setCoverStage((s) => s + 1)}
            />
          </div>
          <h2 className="now-playing-title">{track.title || 'Unknown'}</h2>
          <button
            type="button"
            className="now-playing-artist now-playing-artist-link"
            onClick={() => onOpenArtist(track.artist)}
          >
            {track.artist}
          </button>

          <div className="now-playing-transport">
            <button
              type="button"
              className={`transport-button transport-button-toggle ${shuffle ? 'transport-button-on' : ''}`}
              onClick={onToggleShuffle}
              aria-label="Shuffle"
            >
              <ShuffleIcon />
            </button>
            <button type="button" className="transport-button" onClick={onPrev} aria-label="Previous">
              <PrevIcon />
            </button>
            <button
              type="button"
              className="transport-button transport-button-main now-playing-play accent-fill"
              onClick={onToggle}
              aria-label={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? <PauseIcon size={22} /> : <PlayIcon size={22} />}
            </button>
            <button type="button" className="transport-button" onClick={onNext} aria-label="Next">
              <NextIcon />
            </button>
            <button
              type="button"
              className={`transport-button transport-button-toggle ${repeatMode !== 'off' ? 'transport-button-on' : ''}`}
              onClick={onCycleRepeat}
              aria-label="Repeat"
            >
              <RepeatIcon />
              {repeatMode === 'one' && <span className="repeat-one-dot now-playing-dot accent-fill" />}
            </button>
          </div>

          <div className="now-playing-seek">
            <span className="now-playing-time">{formatTime(currentTime)}</span>
            <input
              type="range"
              className="now-playing-seek-bar accent-range"
              min={0}
              max={duration > 0 ? duration : 100}
              step={0.1}
              value={currentTime}
              onChange={(e) => onSeek(Number(e.target.value))}
              style={{ '--progress': `${seekProgress}%` } as CSSProperties}
            />
            <span className="now-playing-time">{formatTime(duration)}</span>
          </div>
        </div>

        <div className="now-playing-right">
          <div className="now-playing-tabs">
            <button
              type="button"
              className={`now-playing-tab ${tab === 'upnext' ? 'now-playing-tab-active' : ''}`}
              onClick={() => setTab('upnext')}
            >
              UP NEXT
            </button>
            <button
              type="button"
              className={`now-playing-tab ${tab === 'lyrics' ? 'now-playing-tab-active' : ''}`}
              onClick={() => setTab('lyrics')}
            >
              LYRICS
            </button>
            <button
              type="button"
              className={`now-playing-tab ${tab === 'recommended' ? 'now-playing-tab-active' : ''}`}
              onClick={() => setTab('recommended')}
            >
              RECOMMENDED
            </button>
          </div>
          <div className="now-playing-panel">{panelBody}</div>
        </div>
      </div>

      {/* ===== Mobile layout — YouTube Music style ===== */}
      <div className="now-playing-body now-playing-body-mobile">
        <div className="np-mobile-top">
          <button type="button" className="np-mobile-chevron" onClick={onClose} aria-label="Close">
            ⌄
          </button>
        </div>

        <div className="np-mobile-cover-wrap">
          <img
            className="np-mobile-cover"
            src={coverSrc}
            alt=""
            onError={() => setCoverStage((s) => s + 1)}
          />
        </div>

        <div className="np-mobile-meta">
          <h2 className="np-mobile-title">{track.title || 'Unknown'}</h2>
          <button
            type="button"
            className="np-mobile-artist"
            onClick={() => onOpenArtist(track.artist)}
          >
            {track.artist}
          </button>
        </div>

        <div className="np-mobile-seek">
          <input
            type="range"
            className="np-mobile-seek-bar accent-range"
            min={0}
            max={duration > 0 ? duration : 100}
            step={0.1}
            value={currentTime}
            onChange={(e) => onSeek(Number(e.target.value))}
            style={{ '--progress': `${seekProgress}%` } as CSSProperties}
          />
          <div className="np-mobile-times">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        <div className="np-mobile-transport">
          <button
            type="button"
            className={`np-mob-btn ${shuffle ? 'np-mob-btn-on' : ''}`}
            onClick={onToggleShuffle}
            aria-label="Shuffle"
          >
            <ShuffleIcon size={26} />
          </button>
          <button type="button" className="np-mob-btn np-mob-btn-lg" onClick={onPrev} aria-label="Previous">
            <PrevIcon size={36} />
          </button>
          <button
            type="button"
            className="np-mob-play accent-fill"
            onClick={onToggle}
            aria-label={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? <PauseIcon size={32} /> : <PlayIcon size={32} />}
          </button>
          <button type="button" className="np-mob-btn np-mob-btn-lg" onClick={onNext} aria-label="Next">
            <NextIcon size={36} />
          </button>
          <button
            type="button"
            className={`np-mob-btn ${repeatMode !== 'off' ? 'np-mob-btn-on' : ''}`}
            onClick={onCycleRepeat}
            aria-label="Repeat"
          >
            <RepeatIcon size={26} />
            {repeatMode === 'one' && <span className="repeat-one-dot accent-fill" />}
          </button>
        </div>

        {/* Drag hint — swipe up for queue */}
        <button
          type="button"
          className="np-mobile-sheet-handle"
          onClick={() => setSheetOpen(true)}
          aria-label="Open queue"
        >
          <span className="np-handle-bar" />
          <span className="np-handle-label">UP NEXT · LYRICS · RELATED</span>
        </button>
      </div>

      {/* Glass sheet */}
      <div
        className={`np-glass-sheet ${sheetOpen ? 'np-glass-sheet-open' : ''}`}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          className="np-glass-handle"
          onClick={() => setSheetOpen(false)}
          aria-label="Close queue"
        >
          <span className="np-handle-bar" />
        </button>
        <div className="np-glass-mini">
          <img src={track.thumbnail || coverSrc} alt="" />
          <div>
            <div className="np-glass-mini-title">{track.title}</div>
            <div className="np-glass-mini-artist">{track.artist}</div>
          </div>
          <button type="button" className="np-glass-mini-play accent-fill" onClick={onToggle}>
            {isPlaying ? <PauseIcon size={18} /> : <PlayIcon size={18} />}
          </button>
        </div>
        <div className="now-playing-tabs np-glass-tabs">
          <button
            type="button"
            className={`now-playing-tab ${tab === 'upnext' ? 'now-playing-tab-active' : ''}`}
            onClick={() => setTab('upnext')}
          >
            UP NEXT
          </button>
          <button
            type="button"
            className={`now-playing-tab ${tab === 'lyrics' ? 'now-playing-tab-active' : ''}`}
            onClick={() => setTab('lyrics')}
          >
            LYRICS
          </button>
          <button
            type="button"
            className={`now-playing-tab ${tab === 'recommended' ? 'now-playing-tab-active' : ''}`}
            onClick={() => setTab('recommended')}
          >
            RELATED
          </button>
        </div>
        <div className="np-glass-panel">{panelBody}</div>
      </div>

      {/* Sheet backdrop dim */}
      {sheetOpen && (
        <button
          type="button"
          className="np-sheet-dim"
          aria-label="Close sheet"
          onClick={() => setSheetOpen(false)}
        />
      )}
    </div>
  )
}
